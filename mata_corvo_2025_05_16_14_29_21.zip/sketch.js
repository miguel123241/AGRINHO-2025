
  // Variáveis do jogo
let fazendeiro, tiros, corvos;
let velocidadeFazendeiro = 6;
let pontuacao = 0;
let vidas = 3;
let plantacao = [];

function setup() {
  createCanvas(600, 400);
  
  // Inicializa o fazendeiro (posição e tamanho)
  fazendeiro = { 
    x: width / 2, 
    y: height - 40, 
    tamanho: 50 
  };
  
  tiros = [];
  corvos = [];
  
  // Cria a plantação (7 pés de milho 🌽)
  for (let i = 0; i < 7; i++) {
    plantacao.push({ 
      x: i * 80 + 60, 
      y: height - 20 
    });
  }
  
  // Cria 4 corvos iniciais (🐦)
  for (let i = 0; i < 4; i++) {
    spawnCorvo();
  }
}

function draw() {
  background(139, 69, 19); // Fundo marrom (terra)
  
  // Desenha a plantação de milho
  textSize(30);
  for (let planta of plantacao) {
    text("🌽", planta.x, planta.y);
  }
  
  // Desenha o fazendeiro (👨‍🌾)
  textSize(fazendeiro.tamanho);
  text("👨‍🌾", fazendeiro.x - fazendeiro.tamanho/2, fazendeiro.y);
  
  // Atualiza e desenha os tiros (🔫)
  textSize(25);
  for (let i = tiros.length - 1; i >= 0; i--) {
    tiros[i].y -= 9; // Move o tiro para cima
    text("🔫", tiros[i].x, tiros[i].y);
    
    // Remove tiros que saíram da tela
    if (tiros[i].y < 0) {
      tiros.splice(i, 1);
    }
  }
  
  // Atualiza e desenha os corvos (🐦)
  textSize(35);
  for (let i = corvos.length - 1; i >= 0; i--) {
    corvos[i].x += corvos[i].velocidade;
    
    // Muda a direção do corvo a cada segundo (zigue-zague)
    if (frameCount % 60 === 0) {
      corvos[i].velocidade = random(-3, 3);
    }
    
    corvos[i].y += 0.3; // Faz o corvo descer lentamente
    text("🐦", corvos[i].x, corvos[i].y);
    
    // Verifica colisão entre tiro e corvo
    for (let j = tiros.length - 1; j >= 0; j--) {
      if (dist(tiros[j].x, tiros[j].y, corvos[i].x, corvos[i].y) < 25) {
        corvos.splice(i, 1);
        tiros.splice(j, 1);
        pontuacao += 10;
        spawnCorvo(); // Spawna um novo corvo
        break;
      }
    }
    
    // Verifica se o corvo comeu um milho
    for (let k = plantacao.length - 1; k >= 0; k--) {
      if (dist(corvos[i].x, corvos[i].y, plantacao[k].x, plantacao[k].y) < 30) {
        plantacao.splice(k, 1);
        corvos[i].velocidade *= 1.5; // Corvo fica mais rápido
      }
    }
  }
  
  // Mostra HUD (pontuação e vidas)
  textSize(24);
  fill(255);
  text(`Pontos: ${pontuacao}`, 20, 30);
  text(`Vidas: ${vidas}`, 20, 60);
  
  // Verifica se a plantação acabou (perdeu vida)
  if (plantacao.length === 0) {
    vidas--;
    if (vidas > 0) {
      // Recria a plantação
      for (let i = 0; i < 7; i++) {
        plantacao.push({ 
          x: i * 80 + 60, 
          y: height - 20 
        });
      }
    } else {
      // Game Over
      textSize(32);
      fill(255, 0, 0);
      text("💀 Fim da Plantação!", 180, 200);
      noLoop();
    }
  }
  
  // Aumenta a dificuldade (spawna mais corvos)
  if (frameCount % 300 === 0) {
    spawnCorvo();
  }
}

// Função para criar um novo corvo
function spawnCorvo() {
  corvos.push({
    x: random(width),
    y: random(50, 150),
    velocidade: random(-2, 2)
  });
}

// Controles do jogador
function keyPressed() {
  // Movimento do fazendeiro (setas esquerda/direita)
  if (keyCode === LEFT_ARROW && fazendeiro.x > fazendeiro.tamanho/2) {
    fazendeiro.x -= velocidadeFazendeiro;
  }
  if (keyCode === RIGHT_ARROW && fazendeiro.x < width - fazendeiro.tamanho/2) {
    fazendeiro.x += velocidadeFazendeiro;
  }
  
  // Atira (barra de espaço)
  if (key === ' ') {
    tiros.push({ 
      x: fazendeiro.x, 
      y: fazendeiro.y - 30 
    });
  }
}
